<html>
<head>
<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
</head>
<html>
<body>
	<!--men�-->
	<?php
	include("menu.php");
	?>
		<?php
		include("conexion.php");

		$sql="insert into cuentas (fechaCreacion,cedulaCliente,idTipoCuenta,saldo) values 
					('$_REQUEST[fechaCreacion]','$_REQUEST[txtced]','$_REQUEST[txtidtc]','$_REQUEST[saldo]')";
		/*echo $sql;
		exit;*/			

		mysqli_query($conexion,$sql)
					or die("Problemas en el select".mysqli_error($conexion));

		mysqli_close($conexion);

		echo "<div class='jumbotron f' style='margin:200px 50px 50px 50px'>
			  <h1 class='display-4'><b>Cuenta registada corectamente</b></h1>";

		?>
	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>
</body>
</html>
