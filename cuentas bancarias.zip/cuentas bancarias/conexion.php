
<?php
$conexion=mysqli_connect("localhost","root","111","cuentas_bancarias") or
		die("Problemas con la conexi�n");
?>