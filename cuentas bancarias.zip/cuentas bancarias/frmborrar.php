<html>
	<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
		
	</head>
	<body>
	<!--menú-->
	<?php
	include("menu.php");
	?>
		<div class="jumbotron" style="">
			<h1 class="display-4"><b>Borrar un cliente</b></h1>
			<hr class="my-4">				
	
			<form method="post" action="borrar.php">
			
				<p><label><b>Cedula</b></label><br>
				<input type= "text" name="cedula" required
				pattern="^[0-9]{0,12}" title="Sólo se aceptan doce digitos numéricos" placeholder="XXXXXXXXXXXX"></p>
			
				<button type="submit" class="btn btn-outline-success">borrar </button>
			</form>
		</div>	
	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>
	</div>	
	</body>
</html>
