<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
</head>
<html>
<body>
	<!--menú-->
	<?php
	include("menu.php");
	?>
		<?php
		include("conexion.php");

		$registros=mysqli_query($conexion,"SELECT cuentas.consecutivo,C.cedula,C.nombre,C.apellido,Tc.descripcion,cuentas.saldo from cuentas 
		join clientes as C on cuentas.cedulaCliente=C.cedula 
		join tipocuentas as Tc on cuentas.idTipoCuenta=Tc.idTipoCuenta") or
		  die("Problemas en el select:".mysqli_error($conexion));
		  echo "<div class='jumbotron f' style='margin:50px 50px 50px 50px'>
					<h1 class='display-4'><center><b>Listado de cuentas</b></center></h1>
				  <table class='table table-striped'>
				  <thead>
					<tr>
						<th scope='col'>Código de cuenta</th>
						<th scope='col'>Cédula</th>
						<th scope='col'>Nombre</th>
						<th scope='col'>Apellido</th>
						<th scope='col'>Tipo de cuenta</th>
						<th scope='col'>Saldo</th>
					</tr>
				  </thead>
				  <tbody>
				</div>";
			while ($reg=mysqli_fetch_array($registros))
			{
			echo"<tr>";
				echo "<td>".$reg['consecutivo']."</td>";
				echo "<td>".$reg['cedula']."</td>";
				echo "<td>".$reg['nombre']."</td>";
				echo "<td>".$reg['apellido']."</td>";
				echo "<td>".$reg['descripcion']."</td>";
				echo "<td>".$reg['saldo']."</td>";
				echo "<td>";
			echo "</tr>";
		}
		mysqli_close($conexion);
		?>
	<?php
	include("estilosJS.php");
	?>
</body>
</html>