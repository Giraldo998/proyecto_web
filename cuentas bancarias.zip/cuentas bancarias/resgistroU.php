<html>
<head>
<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificaciÃ³n de caracteres-->
		<meta charset="utf-8">
</head>
<html>
<body>
	
	<?php
		include("conexion.php");
		
		$con=$_REQUEST['contraseña'];
		
		//ecriptado
		$con=md5(md5($con));

		mysqli_query($conexion,"insert into usuarios values 
					(1,'$_REQUEST[user]','$con')")
					or die("Problemas en el select".mysqli_error($conexion));

		

		echo"<div class='jumbotron f' style='margin:200px 50px 50px 50px'>
					<h1 class='display-4'><b>Usuario registrado corectamente</b></h1>
					<hr class='my-4'>
					<a class='btn btn-outline-success btn-lg' href='index.php' role='button'>Volver</a>";
		
		mysqli_close($conexion);
	?>
	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>	
</body>
</html>
