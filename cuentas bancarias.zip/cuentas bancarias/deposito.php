<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificaciÃ³n de caracteres-->
		<meta charset="utf-8">	
		
</head>
<body>
	<!--menú-->
	<?php
	include("menu.php");
	?>
		<?php
		include("conexion.php");
			
			//cuenta a la que se le agrega el saldo depositado
			$registros=mysqli_query($conexion,"update cuentas set saldo= saldo+'$_REQUEST[cantidad]' where consecutivo='$_REQUEST[numero]'") 
			or die("Problemas en el select:".mysqli_error($conexion));
			echo "<div class='jumbotron f' style='margin:200px 50px 50px 50px'>
					<h1 class='display-4'><b>Movimiento realizado correctamente</b></h1>";
						
		mysqli_close($conexion);
		?>

	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>
</body>
</html>