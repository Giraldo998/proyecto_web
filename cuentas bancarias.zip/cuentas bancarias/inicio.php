<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
</head>
<body>
	<!--menú-->
	<?php
		include("menu.php");
	?>
		<div class="jumbotron" style="">
		<h1 class="display-4">Banco corp CAP </h1>
		<p class="lead">Bienvenido a la sucrsal virtual del banco corp CAP</p>
		<hr class="my-4">
		<p>Continuar con la gestión de usuarios</p>
		<p class="lead">
			<a class="btn btn-outline-success btn-lg" href="listado.php" role="button">Listar cuentas</a>
		</p>
	</div>
	
	<!--hoja de estilos JS-->
	<?php
		include("estilosJS.php");
	?>
</body>
</html>