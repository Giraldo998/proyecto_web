<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
</head>
<html>
<body>
	<!--menú-->
	<?php
	include("menu.php");
	?>
		<?php
		include("conexion.php");

		$registros=mysqli_query($conexion,"SELECT * from clientes") or
		  die("Problemas en el select:".mysqli_error($conexion));
		  echo "<div class='jumbotron f' style='margin:50px 50px 50px 50px'>
		  <h1 class='display-4'><center><b>Listado de clientes</b></center></h1>
				  <table class='table table-striped'>
				  <thead>
					<tr>
					  <th scope='col'>Cédula</th>
					  <th scope='col'>Nombre</th>
					  <th scope='col'>Apellido</th>
					  <th scope='col'>Teléfono</th>
					  <th scope='col'>Dirección</th>
					  <th scope='col'>Correo</th>
					</tr>
				  </thead>
				  <tbody>
				</div>";
			while ($reg=mysqli_fetch_array($registros))
			{
			echo"<tr>";
				echo "<td>".$reg['cedula']."</td>";
				echo "<td>".$reg['nombre']."</td>";
				echo "<td>".$reg['apellido']."</td>";
				echo "<td>".$reg['telefono']."</td>";
				echo "<td>".$reg['direccion']."</td>";
				echo "<td>".$reg['correo']."</td>";
				echo "<td>";
			echo "</tr>";
		}
		mysqli_close($conexion);
		?>
	<?php
	include("estilosJS.php");
	?>
</body>
</html>