<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
</head>
<html>
<body>
	<!--menú-->
	<?php
	include("menu.php");
	?>
		<?php
		include("conexion.php");

			$registros=mysqli_query($conexion,"select * from clientes where cedula='$_REQUEST[cedula]'") 
			or die("Problemas en el select:".mysqli_error($conexion));

			if($reg=mysqli_fetch_array($registros))
			{

			echo "<div class='jumbotron' style=''>
			<h1 class='display-4'><b>Ingrese nuevos datos</b></h1>
			<hr class='my-4'> 
			
			
				<form action='actcont.php' method='post'>
				
				<p><label><b>cedula: $reg[cedula]</b></label><br>
				<input type= 'hidden' name='cedula' value=$reg[cedula]></p>
				<p><label><b>Nombre</b></label><br>
				<input type= 'text' name='nombre' value=$reg[nombre]></p>
				<p><label><b>Apellido</b></label><br>
				<input type= 'text' name='apellido' value=$reg[apellido]></p>
				<p><label><b>Teléfono</b></label><br>
				<input type= 'text' name='telefono' value=$reg[telefono]></p>
				<p><label><b>Dirección</b></label><br>
				<input type= 'text' name='direccion' value=$reg[direccion]></p>
				<p><label><b>Correo</b></label><br>
				<input type= 'text' name='correo' value=$reg[correo]></p>
				<button type='submit' class='btn btn-outline-success'>Actualizar </button>";
			
			}
			else
			{
				echo "<div class='jumbotron f' style='margin:200px 50px 50px 50px'>
					<h1 class='display-4'><b>No se encontró ningún cliente con ésta cédula</b></h1>";
			}

		mysqli_close($conexion);
		?>
	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>
</body>
</html>