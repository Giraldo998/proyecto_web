<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
	<!--color de fondo y de texto-->	
		
</head>
<body class="f">
	<!--men�-->
	<?php
	include("menu.php");
	?>
		<?php
		include("conexion.php");

			
			$registros=mysqli_query($conexion,"update clientes set cedula='$_REQUEST[cedula]',nombre='$_REQUEST[nombre]',apellido='$_REQUEST[apellido]',
				telefono='$_REQUEST[telefono]',direccion='$_REQUEST[direccion]',correo='$_REQUEST[correo]' 
				where cedula='$_REQUEST[cedula]'") 
			or die("Problemas en el select:".mysqli_error($conexion));
			echo "<div class='jumbotron f' style='margin:200px 50px 50px 50px'>
					<h1 class='display-4'><b>Cliente actualizado correctamente</b></h1>";
			
		?>

	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>
</body>
</html>