<html>
	<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
		
	</head>
	<body>
	<!-- menú-->
	<?php
	include("menu.php");
	?>
	<div class="jumbotron" style="">
			<h1 class="display-4"><b>Registro de cliente</b></h1>
			<hr class="my-4">
		
		<form method="post" action="formulario.php">
		
		<p><label><b>Cedula</b></label><br>
		<input type= "text" name="cedula" required
		pattern="^[0-9]{0,12}" title="Sólo se aceptan doce digitos numéricos" placeholder="XXXXXXXXXXXX"></p>
		
		<p><label><b>Nombre</b></label><br>
		<input type= "text" name="nombre" placeholder="Nombre" required>
		<input type= "text" name="apellido" placeholder="Apellido" required></p>
		
		<p><label><b>Dirección</b></label><br>
		<input type= "text" name="direccion" placeholder="Dirección" required></p>
		
		<p><label><b>Teléfono</b></label><br>
		<input type= "text" name="Telefono" placeholder="Teléfono" required></p>
		
		<p><label><b>Mail</b></label><br>
		<input type= "text" name="correo" placeholder="Mail" required></p>
		
		<button type="submit" class="btn btn-outline-success">Registrar </button>
		</form>	
	</div>	
	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>
	</body>
</html>
