<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
		
	</head>
	<body>
	
	<!-- menú-->
	<?php
	include("menu.php");
	?>
	
	<div class="jumbotron" style="">
			<h1 class="display-4"><b>Registro de cuenta</b></h1>
			<hr class="my-4">
				
		<form method="post" action="registroCuentas.php">

		<?php
		include("conexion.php");

			$cedula=mysqli_query($conexion,"select cedula from clientes") or
			  die("Problemas en el select:".mysqli_error($conexion));
			  
			$tipoC=mysqli_query($conexion,"select * from tipocuentas") or
			  die("Problemas en el select:".mysqli_error($conexion));

		?>
		  
			<p><label><b>Fecha de creación</b></label>
				<input type= "text" name="fechaCreacion" value="<?php echo date('Y-m-d') ?>" readonly></p>	
			
			<label><b>Cédula del cliente</b></label>
				<select name="txtced">
				<?php
					while ($reg=mysqli_fetch_array($cedula))
					{
					 echo "<option value='$reg[cedula]'>$reg[cedula]</option>";
					}
				?>
				</select><br>
			
			<label><b>tipo de cuenta</b></label>
				<select name="txtidtc">
				<?php
					while ($TC=mysqli_fetch_array($tipoC))
					{
					 echo "<option value='$TC[idTipoCuenta]'>$TC[descripcion]</option>";
					}
				?>
				</select><br>
			
			<p><label><b>Ingrese saldo</b></label>
				<input type= "text" name="saldo"></p>	
			
			<button type="submit" class="btn btn-outline-success">Registrar </button>
			</form>	
	</div>
	<?php
	include("estilosJS.php");
	?>
</body>
</html>