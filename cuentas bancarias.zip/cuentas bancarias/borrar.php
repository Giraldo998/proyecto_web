<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
</head>
<html>
<body>
	<!--menú-->
	<?php
	include("menu.php");
	?>
		<?php
		include("conexion.php");

			$registros=mysqli_query($conexion,"SELECT cedula from clientes where cedula='$_REQUEST[cedula]'") 
			or die("Problemas en el select:".mysqli_error($conexion));
			
			if($reg=mysqli_fetch_array($registros))
			{
			$registros=mysqli_query($conexion,"delete from clientes where cedula='$_REQUEST[cedula]'") 
			or die("Problemas en el select:".mysqli_error($conexion));
			echo "<div class='jumbotron f' style='margin:200px 50px 50px 50px'>
					<h1 class='display-4'><b>Cliente borrado correctamente</b></h1>";
			
			}
			else
			{
				echo "<div class='jumbotron f' style='margin:200px 50px 50px 50px'>
					<h1 class='display-4'><b>No se encontró ningún cliente con este documento</b></h1>";
			}
			

		mysqli_close($conexion);
		?>
	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>	
</body>
</html>