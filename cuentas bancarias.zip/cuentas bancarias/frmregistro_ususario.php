<html>
	<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
		
	</head>
	<body>
	
	<div class="jumbotron" style="">
			<h1 class="display-4"><b>Registro de un nuevo usuario</b></h1>
			<hr class="my-4">
					
		<form method="post" action="resgistroU.php">
		
		<p><label><b>Nombre de usuario</b></label><br>
		<input type= "text" name="user" required
		pattern="^{50}" title="Sólo cincuenta caracteres" placeholder="Ej:staxxx"></p>
		
		<p><label><b>Contraseña</b></label><br>
		<input type= "password" name="contraseña" placeholder="XXXXXXXXXXXX" required><br><br>
		
		
		<button type="submit" class="btn btn-outline-success">Registrar </button>
		</form>	
	</div>
	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>
	</div>	
	</body>
</html>