<html>
<head>
	<!--hoja de estilos css-->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--codificación de caracteres-->
		<meta charset="utf-8">
		<style>
		.f
		{
		background-color:#343D34;
			color:white;
		}
		</style>
</head>
<body style="background-color: #1E251E">
	
		<div class="jumbotron f" style="margin:30px 500px 500px 500px">
			<h1 class="display-4">Banco corp CAP </h1>
			<form method="post" action="login.php">
				<p class="lead"><h3>Inicio de sesión</h3></p>
				<p><label><b>Usuario</b></label><br>
				<input type= "text " name="usuario" placeholder="Usuario" required></p>
				
				<p><label><b>Contraseña</b></label><br>
				<input type= "password" name="contraseña" placeholder="Contraseña" required></p>
				<p class="lead">
				<a href="frmregistro_ususario.php"><h6>Crear ususario</h6></a>
				<hr class="my-4">
					<button type="submit" class="btn btn-outline-success btn-lg" >Ingresar</button></p>
			</form>
		</div>
	
	<!--hoja de estilos JS-->
	<?php
	include("estilosJS.php");
	?>
</body>
</html>